"""Siglent SDG6000X-E 系列信号发生器的 SCPI 客户端。

通信链路（本机实测确认）
------------------------
USB-device 口枚举为 USBTMC 类设备（Class FE/Sub 03/Prot 01），
给该设备绑定 WinUSB 驱动后，用 ``pyvisa-py`` 纯 Python 后端通信，
**不需要 NI-VISA**：

    VID:PID   0xF4EC:0x1101
    序列号    SDG6XFCQA00575
    资源串    USB0::0xF4EC::0x1101::SDG6XFCQA00575::0::INSTR
    固件      6.01.01.38R3

六条实测出来的使用约束（每条都踩过坑，别按通用 SCPI 直觉写）
============================================================

1. **单位后缀会被静默忽略** —— 最危险的一条::

       C1:BSWV AMP,3mV    -> 实际输出 3 V      （差 1000 倍，不报错）
       C1:BSWV FRQ,2KHZ   -> 实际输出 2 Hz     （差 1000 倍，不报错）
       C1:BSWV WIDTH,100US-> 实际约 1 ms

   设备只认裸数字：值按该字段的**基准单位**解释（V / Hz / s）。
   错误队列始终是 ``0,"No error"``，没有任何反馈。
   因此本模块的公开 API **只接受数字**，单位由字段本身决定；
   传字符串会被拒绝，避免"以为设了 mV 其实输出了 V"这种事故。

2. **子查询不存在**。``C1:BTWV STATE?``、``C1:BSWV FRQ?`` 一律超时。
   必须查整条：``C1:BSWV?`` 返回逗号分隔的全部字段。

3. **整条查询串不能原样回写**。``C1:BSWV?`` 的返回值含只读字段
   （``PERI``、``AMPVRMS``、``MAX_OUTPUT_AMP`` 等），直接 ``write``
   回去实测会把 ``PHSE`` 从 0 改成 1、``DLY`` 从 0S 改成 -2.8 ms。
   故 :meth:`write_fields` 只下发显式列出的字段。

4. **非法命令不报错**。写一个不存在的字段，设备既不返回错误、
   也不进错误队列，只是忽略。所以"设完回读核对"是唯一可靠的验收手段。

5. **每条命令带来约 30 ms 的"写入死区"，线性累加**。实测::

       写 1 条   -> *OPC? 等 24 ms
       写 5 条   -> 等 141 ms
       写 20 条  -> 等 613 ms
       写 40 条  -> 等 1205 ms     即 ~30 ms/条，与内容无关

   死区本身不阻塞后续写入（纯写 0.054 ms/条），只在**要读回**时
   才必须等它走完。故策略是：**能批量写就批量写，只在真正需要读回时
   等一次**。一次完整波形设置若拆成 5 条命令，就要多等 150 ms。

6. **新建 ResourceManager 会关掉已有会话**（pyvisa-py 的 ``@py`` 后端
   缺陷）。设备已打开时再调 :func:`find_resources` 会让手上这个会话
   变成 InvalidSession。函数内部用 ``try/except`` 标注了这一点。

Burst（脉冲串）是 LFA 要用的关键功能：连续波激光必须被切成短脉冲，
靠 Burst 把 N 个周期的载波以"单次触发"方式送出去。
"""

from __future__ import annotations

from dataclasses import dataclass

#: 默认资源串。序列号随设备而定，可用 :func:`find_resources` 列出。
DEFAULT_RESOURCE = "USB0::0xF4EC::0x1101::SDG6XFCQA00575::0::INSTR"

#: 枚举型字段：值本来就是字符串（如 WVTP=SQUARE、TRSR=EXT），不套单位检查
_ENUM_FIELDS = {"WVTP", "STATE", "TRSR", "GATE_NCYC", "SWWV", "MDWV",
                "PLRT", "TYPE", "MODE", "POLARITY", "BYTEORDER"}

#: 少数字段读回来带单位后缀，解析时统一剥掉（只用于读，写只给数字）
_UNIT_SUFFIXES = ("Vrms", "dBm", "V", "S", "s", "HZ", "Hz")


@dataclass(frozen=True)
class DeviceInfo:
    """设备识别信息（写进 CSV 与日志用）。"""

    idn: str
    vendor: str
    model: str
    serial: str
    firmware: str


class SDGError(RuntimeError):
    """SCPI 命令被设备拒绝，或参数不符合本模块的安全约束。"""


def find_resources() -> list[str]:
    """列出本机所有 USB 仪器资源串。

    .. warning::
       设备已经打开时**不要调用**：pyvisa-py 的 ``@py`` 后端里，新建
       ``ResourceManager`` 会把已有会话关掉（实测 ``InvalidSession``）。
       需要资源串时请在 :meth:`SDG6000X.open` 之前取好。
    """
    import pyvisa

    rm = pyvisa.ResourceManager("@py")
    try:
        return [r for r in rm.list_resources() if r.startswith("USB")]
    finally:
        rm.close()


def parse_fields(reply: str, prefix: str = "") -> dict[str, str]:
    """把 ``C1:BSWV WVTP,SQUARE,FRQ,1HZ,...`` 解析成 dict。

    SCPI 的整条查询是"键,值,键,值..."的平铺格式。但有几个键**没有值**
    （``C1:OUTP ON,LOAD,HZ,...`` 里的 ``ON`` 是状态而不是键），
    因此不能简单两两配对，而要按"已知键名"识别。

    这里采用的做法：把 token 按顺序看，若某个 token 是已知键名，
    则它后面的 token 是它的值；否则该 token 是"上一条命令的主状态"。
    """
    text = reply.strip()
    if prefix and text.upper().startswith(prefix.upper()):
        text = text[len(prefix):].strip()
    toks = [p.strip() for p in text.split(",") if p.strip()]
    if not toks:
        return {}

    # 首个 token 可能是主状态（如 OUTP 的 ON/OFF、SYNC 的 ON/OFF）
    out: dict[str, str] = {}
    i = 0
    first = toks[0].upper()
    if first in ("ON", "OFF"):
        out[prefix.split(":")[-1].upper() if prefix else "STATE"] = first
        i = 1
    while i < len(toks) - 1:
        key = toks[i].upper()
        out[key] = toks[i + 1]
        i += 2
    return out


def _num(value, field: str) -> str:
    """把数值转成 SCPI 字符串；拒绝带单位的字符串。

    这是第 1 条约束的守门人：设备会把 ``3mV`` 当成 3（伏），
    所以宁可在这里报错，也不能把带单位的字符串发下去。
    """
    if isinstance(value, bool):
        raise SDGError(f"{field} 不接受布尔值")
    if isinstance(value, (int, float)):
        return f"{value:g}"
    text = str(value).strip()
    try:
        return f"{float(text):g}"
    except ValueError:
        raise SDGError(
            f"{field} 只接受数字（该字段基准单位），收到 {value!r}。\n"
            f"注意：本设备会忽略单位后缀 —— 传 '3mV' 实际输出 3 V，"
            f"传 '2KHZ' 实际输出 2 Hz。请改用 0.003 和 2000。") from None


def to_number(text: str, default: float = float("nan")) -> float:
    """把 ``'2000HZ'`` / ``'3V'`` / ``'0.001S'`` 这类读回值转成数字。

    读回来的字段多数带单位后缀，写的时候则不能带（见模块文档第 1 条）。
    这里只为"读后比对"服务。
    """
    if not text:
        return default
    s = text.strip()
    for suf in _UNIT_SUFFIXES:
        if s.endswith(suf):
            s = s[: -len(suf)]
            break
    try:
        return float(s)
    except ValueError:
        return default


def strip_eol(text: str) -> str:
    return text.rstrip("\r\n")


class SDG6000X:
    """最小可用的 SDG6000X-E 客户端。

    只做"命令 -> 字符串"的搬运与状态解析，不含界面或采集逻辑。
    """

    def __init__(self, resource: str = DEFAULT_RESOURCE, timeout_ms: int = 3000):
        self.resource = resource
        self.timeout_ms = timeout_ms
        self._inst = None
        self._rm = None

    # ---------- 连接 ----------
    def open(self) -> None:
        import pyvisa

        # 自己持有 ResourceManager：避免每次操作新建一个（会关掉会话）
        self._rm = pyvisa.ResourceManager("@py")
        self._inst = self._rm.open_resource(self.resource,
                                            timeout=self.timeout_ms)
        self._inst.read_termination = "\n"
        self._inst.write_termination = "\n"

    def close(self) -> None:
        if self._inst is not None:
            try:
                self._inst.close()
            finally:
                self._inst = None
        if self._rm is not None:
            try:
                self._rm.close()
            finally:
                self._rm = None

    def __enter__(self):
        self.open()
        return self

    def __exit__(self, *exc):
        self.close()

    @property
    def is_open(self) -> bool:
        return self._inst is not None

    # ---------- 底层 ----------
    def write(self, cmd: str) -> None:
        if self._inst is None:
            raise RuntimeError("设备未打开")
        self._inst.write(cmd)

    def query(self, cmd: str) -> str:
        if self._inst is None:
            raise RuntimeError("设备未打开")
        return strip_eol(self._inst.query(cmd))

    def write_many(self, cmds: list[str], sync: bool = True) -> None:
        """批量写，可选最后统一 ``*OPC?`` 同步一次。

        设备每条命令带来约 30 ms 写入死区（见模块文档第 5 条），
        所以要尽量把一次设置合并成**少数几条**命令，而不是一条一查。

        ``sync=False`` 时不等待——适合"发完就走、稍后再读"的场景。
        """
        for cmd in cmds:
            self.write(cmd)
        if sync:
            self.wait_ready()

    # ---------- 身份与错误 ----------
    def identify(self) -> DeviceInfo:
        raw = self.query("*IDN?")
        parts = [p.strip() for p in raw.split(",")]
        while len(parts) < 4:
            parts.append("")
        return DeviceInfo(idn=raw, vendor=parts[0], model=parts[1],
                          serial=parts[2], firmware=parts[3])

    def clear_status(self) -> None:
        self.write("*CLS")

    def last_error(self) -> str:
        return self.query("SYST:ERR?")

    def drain_errors(self) -> list[str]:
        out = []
        for _ in range(20):
            err = self.last_error()
            out.append(err)
            if err.startswith("0"):
                break
        return out

    # ---------- 基本波形 ----------
    def read_basic(self, ch: int = 1) -> dict[str, str]:
        return parse_fields(self.query(f"C{ch}:BSWV?"), f"C{ch}:BSWV")

    def write_fields(self, ch: int, **fields) -> None:
        """只写指定字段。数值字段必须是数字，枚举字段原样传字符串。"""
        if not fields:
            return
        parts = []
        for k, v in fields.items():
            key = k.upper()
            parts.append(f"{key},{v}" if key in _ENUM_FIELDS
                         else f"{key},{_num(v, key)}")
        self.write(f"C{ch}:BSWV " + ",".join(parts))

    def set_square(self, ch: int = 1, freq_hz: float = 1000.0,
                   amp_vpp: float = 5.0, offset_v: float = 2.5,
                   duty_pct: float = 50.0) -> None:
        """设方波。LFA 里用方波驱动激光的开关。

        ``amp_vpp`` 是**峰峰值**（Vpp），``offset_v`` 是直流偏置，
        两者共同决定高/低电平：高 = offset + amp/2，低 = offset - amp/2。
        """
        self.write_fields(ch, WVTP="SQUARE", FRQ=float(freq_hz),
                          AMP=float(amp_vpp), OFST=float(offset_v),
                          DUTY=float(duty_pct))

    def set_sine(self, ch: int = 1, freq_hz: float = 1000.0,
                 amp_vpp: float = 5.0, offset_v: float = 0.0,
                 phase_deg: float = 0.0) -> None:
        self.write_fields(ch, WVTP="SINE", FRQ=float(freq_hz),
                          AMP=float(amp_vpp), OFST=float(offset_v),
                          PHSE=float(phase_deg))

    def set_pulse(self, ch: int = 1, freq_hz: float = 1000.0,
                  amp_vpp: float = 5.0, offset_v: float = 2.5,
                  width_s: float = 100e-6) -> None:
        """设脉冲波形（脉冲形状本身，不是 Burst）。

        ``width_s`` 单位是**秒**：100 us 要写成 ``100e-6``。
        写 ``"100US"`` 会被静默当成 100（秒级）而被设备夹到合法上限。
        """
        self.write_fields(ch, WVTP="PULSE", FRQ=float(freq_hz),
                          AMP=float(amp_vpp), OFST=float(offset_v),
                          WIDTH=float(width_s))

    # ---------- 输出开关 ----------
    def read_output(self, ch: int = 1) -> dict[str, str]:
        return parse_fields(self.query(f"C{ch}:OUTP?"), f"C{ch}:OUTP")

    def is_output_on(self, ch: int = 1) -> bool:
        return self.read_output(ch).get("OUTP", "").upper() == "ON"

    def output(self, ch: int = 1, on: bool = True,
               high_z: bool = True) -> None:
        """开/关输出。``high_z=True`` 设高阻负载。

        接高阻输入（如示波器 1 MΩ）时若负载设 50 Ω，实际幅度会翻倍，
        这是"设了 5 V 却量到 10 V"的常见原因，故默认高阻。
        """
        load = ",LOAD,HZ" if high_z else ""
        self.write(f"C{ch}:OUTP {'ON' if on else 'OFF'}{load}")

    def output_on(self, ch: int = 1) -> None:
        self.output(ch, True)

    def output_off(self, ch: int = 1) -> None:
        self.output(ch, False)

    # ---------- Burst（脉冲串）----------
    def read_burst(self, ch: int = 1) -> dict[str, str]:
        return parse_fields(self.query(f"C{ch}:BTWV?"), f"C{ch}:BTWV")

    def burst_state(self, ch: int = 1) -> bool:
        return self.read_burst(ch).get("STATE", "").upper() == "ON"

    def burst_on(self, ch: int = 1, cycles: int = 1,
                 trigger: str = "EXT", period_s: float | None = None) -> None:
        """开启 Burst：输出 ``cycles`` 个载波周期后停止，等待下次触发。

        ``trigger``:

        * ``"EXT"`` —— 等外部触发到来才输出。**LFA 必须用这个**：
          波形发生器先准备好，触发时刻才可控，而不是"下发命令的时刻"
          （命令往返有几十毫秒抖动，做时间零点会毁掉拟合）。
        * ``"INT"`` —— 内部按周期自动重复（用于连续脉冲序列）。
        * ``"BUS"`` —— 软件触发（配合 :meth:`manual_trigger`）。
        """
        parts = ["STATE,ON", f"STPS,{int(cycles)}",
                 f"TRSR,{trigger.upper()}", "GATE_NCYC,NCYC"]
        if period_s is not None:
            parts.append(f"PRD,{_num(period_s, 'PRD')}")
        self.write(f"C{ch}:BTWV " + ",".join(parts))

    def burst_off(self, ch: int = 1) -> None:
        self.write(f"C{ch}:BTWV STATE,OFF")

    def burst_burst_time(self, ch: int = 1, seconds: float = 1e-3) -> None:
        """Burst 的 ``TIME`` 参数（GATE 模式下的门宽）。

        .. warning::
           实测该字段对写入几乎不敏感（写 0.001 / 1US 读回都是 1），
           语义尚不明确。**不要依赖它控制脉宽**——脉宽应由载波频率
           与 ``cycles`` 决定：脉宽 ≈ cycles / freq。
        """
        self.write(f"C{ch}:BTWV TIME,{_num(seconds, 'TIME')}")

    # ---------- 触发与同步 ----------
    def manual_trigger(self, ch: int = 1) -> None:
        """手动发一次触发（Burst 配 ``TRSR,BUS`` 时用）。"""
        self.write(f"C{ch}:BTWV MTRIG")

    def read_sync(self, ch: int = 1) -> dict[str, str]:
        return parse_fields(self.query(f"C{ch}:SYNC?"), f"C{ch}:SYNC")

    def sync(self, ch: int = 1, on: bool = True) -> None:
        self.write(f"C{ch}:SYNC {'ON' if on else 'OFF'}")

    # ---------- 时间基准 ----------
    def read_rosc(self) -> dict[str, str]:
        return parse_fields(self.query("ROSC?"), "ROSC")

    # ---------- 快照与恢复 ----------
    def snapshot(self, ch: int = 1) -> dict[str, dict[str, str]]:
        """把该通道全部可读状态收成快照，便于测试后原样恢复。"""
        return {
            "basic": self.read_basic(ch),
            "output": self.read_output(ch),
            "burst": self.read_burst(ch),
            "sync": self.read_sync(ch),
        }

    def restore(self, ch: int, snap: dict[str, dict[str, str]]) -> None:
        """按 :meth:`snapshot` 恢复。只写可写字段，不整条回写。"""
        b = snap.get("basic", {})
        cmds: list[str] = []
        writable = {}
        for key in ("WVTP", "FRQ", "AMP", "OFST", "PHSE", "DUTY",
                    "WIDTH", "RISE", "FALL", "DLY"):
            if key in b:
                writable[key] = b[key]
        if writable:
            body = ",".join(f"{k},{v}" for k, v in writable.items())
            cmds.append(f"C{ch}:BSWV {body}")

        br = snap.get("burst", {})
        if br.get("STATE", "").upper() == "OFF":
            cmds.append(f"C{ch}:BTWV STATE,OFF")
        else:
            parts = ["STATE,ON"]
            for key in ("STPS", "TRSR", "GATE_NCYC", "TIME", "PRD"):
                if key in br:
                    parts.append(f"{key},{br[key]}")
            cmds.append(f"C{ch}:BTWV " + ",".join(parts))

        sy = snap.get("sync", {})
        cmds.append(f"C{ch}:SYNC "
                    f"{'ON' if sy.get('SYNC', '').upper() == 'ON' else 'OFF'}")

        # 输出开关放最后：避免恢复过程中有毛刺送出去
        op = snap.get("output", {})
        cmds.append(f"C{ch}:OUTP "
                    f"{'ON' if op.get('OUTP', '').upper() == 'ON' else 'OFF'}")
        self.write_many(cmds)

    # ---------- 就绪 ----------
    def wait_ready(self) -> None:
        """等设备执行完（``*OPC?`` 在操作完成前不返回）。超时由会话控制。"""
        self.query("*OPC?")

    # ---------- LFA 专用组合 ----------
    def setup_lfa_pulse(self, ch: int = 1, freq_hz: float = 1000.0,
                        cycles: int = 1, amp_vpp: float = 5.0,
                        offset_v: float = 2.5, high_z: bool = True) -> float:
        """把通道配成"等外部触发的单次脉冲"，返回预期脉宽（秒）。

        这是 LFA 的核心动作：激光器需要**一个**已知宽度的脉冲，
        而脉宽 = cycles / freq。用 Burst 而不是脉冲波形，是因为
        Burst 能做到"准备好、等触发"，触发时刻才是可控的时间零点。

        实现上刻意只用 **2 条命令**（波形 + Burst），因为每条命令约
        30 ms 死区；若拆成 6 条就要多等 180 ms，会拖慢每次测量前的
        准备时间，也让"下发命令 -> 触发到来"这段不确定度变大。
        """
        if cycles < 1:
            raise SDGError("cycles 至少为 1")
        if freq_hz <= 0:
            raise SDGError("freq_hz 必须为正")
        # 第 1 条：载波波形（Burst 实际输出的就是这组参数）
        self.write(f"C{ch}:BSWV WVTP,SQUARE,FRQ,{freq_hz:g},"
                   f"AMP,{amp_vpp:g},OFST,{offset_v:g},DUTY,50")
        # 第 2 条：Burst，外部触发、单次、N 个周期
        self.write(f"C{ch}:BTWV STATE,ON,STPS,{int(cycles)},"
                   f"TRSR,EXT,GATE_NCYC,NCYC")
        # 第 3 条：输出开关与负载
        self.write(f"C{ch}:OUTP ON{',LOAD,HZ' if high_z else ''}")
        return int(cycles) / float(freq_hz)

    def arm_and_wait(self, ch: int = 1, timeout_s: float = 5.0) -> float:
        """等 Burst 真正触发完成，返回实际等待时间（秒）。

        设备没有"触发了没有"的查询命令（``COUNTER`` 字段只在 EXT 模式
        下出现，且读它本身要经过 30 ms 死区）。这里用 ``*OPC?`` 阻塞到
        设备认为本次 Burst 结束，作为"脉冲已发完"的粗判据。

        .. warning::
          这**不是**时间零点。真正的零点必须靠外部触发信号的边沿
          （示波器/计数器打点），精度才能到微秒级。本函数只用于
          "确认这一发已经打完"，不能用于计时。
        """
        import time as _t

        t0 = _t.perf_counter()
        self.query("*OPC?")
        dt = _t.perf_counter() - t0
        if dt > timeout_s:
            raise TimeoutError(f"等待 Burst 完成超过 {timeout_s} s")
        return dt
