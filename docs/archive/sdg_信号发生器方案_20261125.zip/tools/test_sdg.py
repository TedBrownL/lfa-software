"""SDG6022X-E 通信自检：单独验证"输出"和"输入"两条路。

这个脚本独立于测温软件，专门回答一个问题：
**我能不能可靠地控制信号发生器，并读回它的真实状态。**

为什么"读回核对"是这个脚本的核心
--------------------------------
本设备实测有三处**静默失败**：单位后缀被忽略、子查询不存在、
非法命令不报错。三者都不会抛异常、错误队列也是干净的。
唯一可靠的办法是**写完立刻读回、比对真实值**。

安全性
------
* 开始先快照 CH1/CH2 的 basic/output/burst/sync；
* ``try/finally`` 保证异常时也恢复；
* 结束默认关闭输出（原状态是 ON，但测试期间不该让波形一直送出去）。

用法::

    python tools/test_sdg.py
    python tools/test_sdg.py --ch 2 --keep-output
"""

from __future__ import annotations

import argparse
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from lfa.sdg import SDG6000X, SDGError, find_resources, to_number


def hr(title: str) -> None:
    print(f"\n{'=' * 64}\n{title}\n{'=' * 64}")


def ok(flag: bool) -> str:
    return "✅" if flag else "❌"


def num(text: str, default: float = float("nan")) -> float:
    return to_number(text, default)


def close_to(a: float, b: float, rel: float = 0.02) -> bool:
    if a != a or b != b:          # NaN
        return False
    return abs(a - b) <= max(abs(b) * rel, 1e-12)


class Results:
    def __init__(self) -> None:
        self.items: list[tuple[str, bool, str]] = []

    def add(self, name: str, passed: bool, detail: str = "") -> None:
        self.items.append((name, passed, detail))
        print(f"  {ok(passed)} {name}" + (f"   [{detail}]" if detail else ""))

    def summary(self) -> bool:
        hr("汇总")
        for name, passed, detail in self.items:
            print(f"  {ok(passed)} {name}" + (f"   [{detail}]" if detail else ""))
        bad = [n for n, p, _ in self.items if not p]
        print()
        if bad:
            print(f"❌ {len(bad)} 项未通过：" + "、".join(bad))
            return False
        print(f"✅ 全部 {len(self.items)} 项通过")
        return True


def main() -> int:
    ap = argparse.ArgumentParser(description="SDG6022X-E 通信自检")
    ap.add_argument("--resource", default=None)
    ap.add_argument("--keep-output", action="store_true")
    ap.add_argument("--ch", type=int, default=1)
    args = ap.parse_args()
    ch = args.ch
    res = Results()

    hr("1. 发现设备")
    # 必须在 open() 之前枚举：pyvisa-py 里新建 RM 会关掉已有会话
    resources = [args.resource] if args.resource else find_resources()
    print(f"  USB 仪器资源 {len(resources)} 个:")
    for r in resources:
        print(f"    {r}")
    if not resources:
        print("\n❌ 没找到仪器。请确认信号发生器已开机、USB 已接。")
        return 1

    dev = SDG6000X(resources[0])
    snap: dict[int, dict] = {}
    try:
        hr("2. 连接与身份")
        t0 = time.perf_counter()
        dev.open()
        dt_open = (time.perf_counter() - t0) * 1e3
        info = dev.identify()
        print(f"  厂商 {info.vendor} / 型号 {info.model}")
        print(f"  序列号 {info.serial} / 固件 {info.firmware}")
        print(f"  打开耗时 {dt_open:.0f} ms")
        res.add("连接建立", True, f"{dt_open:.0f} ms")
        res.add("型号属于 SDG6000X-E 系列", "SDG60" in info.model, info.model)

        hr("3. 输入：读整条状态")
        t0 = time.perf_counter()
        basic = dev.read_basic(ch)
        dt_q = (time.perf_counter() - t0) * 1e3
        print(f"  单次查询 {dt_q:.1f} ms，解析出 {len(basic)} 个字段")
        for k in ("WVTP", "FRQ", "AMP", "OFST", "PHSE", "DUTY"):
            print(f"    {k:6s} = {basic.get(k, '<缺失>')}")
        res.add("整条查询可解析", bool(basic.get("WVTP")))
        res.add("单次查询 < 100 ms", dt_q < 100, f"{dt_q:.1f} ms")

        out = dev.read_output(ch)
        burst = dev.read_burst(ch)
        sync = dev.read_sync(ch)
        print(f"  OUTP = {out.get('OUTP', '?')}   "
              f"BTWV = {burst.get('STATE', '?')}   "
              f"SYNC = {sync.get('SYNC', '?')}")
        res.add("输出状态可解析", out.get("OUTP") in ("ON", "OFF"),
                str(out.get("OUTP")))

        snap[ch] = {"basic": basic, "output": out,
                    "burst": burst, "sync": sync}
        print("  已快照当前状态")

        hr("4. 输出：写参数并读回核对")
        want_f = 2000.0
        want_a = 3.0
        dev.write_fields(ch, WVTP="SQUARE", FRQ=want_f, AMP=want_a)
        back = dev.read_basic(ch)
        got_f, got_a = num(back.get("FRQ", "")), num(back.get("AMP", ""))
        print(f"  写 FRQ={want_f:g} AMP={want_a:g}")
        print(f"  读 FRQ={back.get('FRQ')} AMP={back.get('AMP')}")
        res.add("频率写入生效", close_to(got_f, want_f), f"{got_f:g} Hz")
        res.add("幅度写入生效", close_to(got_a, want_a), f"{got_a:g} Vpp")
        res.add("未误改相位 PHSE", back.get("PHSE") == basic.get("PHSE"),
                f"{basic.get('PHSE')} -> {back.get('PHSE')}")

        hr("5. 单位后缀陷阱（本设备最危险的坑）")
        print("  设备忽略单位后缀，只认裸数字。验证这条防护是否生效：")
        blocked = 0
        for bad in ("3mV", "2KHZ", "100US"):
            try:
                dev.write_fields(ch, AMP=bad)
            except SDGError:
                blocked += 1
                print(f"    ✅ 拒绝 {bad!r}（会差 1000 倍）")
        res.add("带单位的字符串被拒绝", blocked == 3, f"拦住 {blocked}/3")

        # 对照：裸数字确实按基准单位解释
        dev.write_fields(ch, AMP=0.003)
        tiny = dev.read_basic(ch)
        rms_small = num(tiny.get("AMPVRMS", ""))
        dev.write_fields(ch, AMP=3.0)
        big = dev.read_basic(ch)
        rms_big = num(big.get("AMPVRMS", ""))
        print(f"  AMP=0.003 -> AMPVRMS={tiny.get('AMPVRMS')}")
        print(f"  AMP=3     -> AMPVRMS={big.get('AMPVRMS')}")
        res.add("裸数字按基准单位解释",
                close_to(rms_small * 1000, rms_big, rel=0.05),
                "0.003 V 与 3 V 相差约 1000 倍")

        hr("6. Burst 脉冲串（LFA 关键功能）")
        want_cycles = 1
        t0 = time.perf_counter()
        dev.burst_on(ch, cycles=want_cycles, trigger="EXT")
        dt_burst = (time.perf_counter() - t0) * 1e3
        b2 = dev.read_burst(ch)
        print(f"  设置耗时 {dt_burst:.1f} ms（含读回）")
        print(f"  STATE={b2.get('STATE')} STPS={b2.get('STPS')} "
              f"TRSR={b2.get('TRSR')} GATE_NCYC={b2.get('GATE_NCYC')}")
        res.add("Burst 可开启", b2.get("STATE", "").upper() == "ON")
        res.add("Burst 周期数正确", b2.get("STPS") == str(want_cycles),
                b2.get("STPS", ""))
        res.add("触发源为 EXT（时间零点可控）",
                b2.get("TRSR", "").upper() == "EXT", b2.get("TRSR", ""))
        dev.burst_off(ch)

        # 脉冲宽度由 载波频率 与 cycles 共同决定，这才是可靠的控制方式
        print("\n  验证脉宽 = cycles / freq（不要依赖 BTWV TIME）：")
        for freq, cyc in ((1000.0, 1), (1000.0, 10), (10000.0, 5)):
            dev.write_fields(ch, WVTP="SQUARE", FRQ=freq, AMP=3.0)
            dev.burst_on(ch, cycles=cyc, trigger="EXT")
            bb = dev.read_burst(ch)
            carr_f = num(bb.get("FRQ", "") or bb.get("CARR", ""), freq)
            expect_ms = cyc / freq * 1e3
            print(f"    freq={freq:>7g} Hz  cycles={cyc:>2d}  "
                  f"-> 预期脉宽 {expect_ms:.3f} ms")
            dev.burst_off(ch)
        res.add("可批量设置不同脉宽组合", True, "3 组")

        hr("7. 时序：写入吞吐与写入后死区")
        # 纯写入不需要等设备回话，这是"能否做高频控制"的真实指标
        cmds = [f"C{ch}:BSWV FRQ,{1000 + i}" for i in range(20)]
        t0 = time.perf_counter()
        for c in cmds:
            dev.write(c)
        dt_pure = (time.perf_counter() - t0) * 1e3
        print(f"  纯写 20 条: {dt_pure:.2f} ms = {dt_pure / 20:.3f} ms/条")

        # 写入后设备有一段不应答期，*OPC? 必须等它过去
        t0 = time.perf_counter()
        dev.query("*OPC?")
        dt_opc = (time.perf_counter() - t0) * 1e3
        print(f"  写后首次 *OPC? 等待: {dt_opc:.1f} ms"
              f"  ← 这就是写入死区")
        res.add("纯写入 20 条 < 20 ms", dt_pure < 20, f"{dt_pure:.1f} ms")

        dev.write_many([f"C{ch}:BSWV FRQ,1000"])     # 同步到已知状态
        t0 = time.perf_counter()
        dev.write(f"C{ch}:BSWV FRQ,1000")
        dev.query(f"C{ch}:BSWV?")
        dt_one = (time.perf_counter() - t0) * 1e3
        print(f"  写+读回 1 条: {dt_one:.1f} ms（含写入死区）")
        res.add("写+核对 1 条 < 300 ms", dt_one < 300, f"{dt_one:.0f} ms")

        hr("8. LFA 组合配置（一条命令搞定一次脉冲）")
        print("  setup_lfa_pulse 只发 3 条命令，避免 30 ms/条 的死区累加")
        lfa_ok = 0
        for freq, cyc in ((1000.0, 1), (5000.0, 2), (10000.0, 10)):
            t0 = time.perf_counter()
            width = dev.setup_lfa_pulse(ch, freq_hz=freq, cycles=cyc)
            dt_set = (time.perf_counter() - t0) * 1e3
            bb = dev.read_burst(ch)
            bsc = dev.read_basic(ch)
            good = (close_to(num(bsc.get("FRQ", "")), freq)
                    and bb.get("STPS") == str(cyc)
                    and bb.get("TRSR", "").upper() == "EXT"
                    and bb.get("STATE", "").upper() == "ON")
            lfa_ok += 1 if good else 0
            print(f"    freq={freq:>7g} cycles={cyc:>2d} "
                  f"脉宽={width * 1e3:6.3f} ms  下发 {dt_set:.2f} ms  "
                  f"{'✅' if good else '❌'}")
            dev.burst_off(ch)
        res.add("LFA 脉冲配置正确", lfa_ok == 3, f"{lfa_ok}/3 组")

        hr("9. 错误队列（应始终为空）")
        errs = dev.drain_errors()
        print(f"  {errs}")
        res.add("错误队列干净", len(errs) == 1 and errs[0].startswith("0"),
                errs[0] if errs else "")

    except Exception as exc:
        print(f"\n❌ 异常中断: {type(exc).__name__}: {exc}")
        import traceback
        traceback.print_exc()
        res.add("无异常中断", False, type(exc).__name__)
    finally:
        hr("10. 恢复与收尾")
        try:
            if snap:
                dev.restore(ch, snap[ch])
                print(f"  已恢复 CH{ch} 到测试前状态")
                if not args.keep_output:
                    dev.output_off(ch)
                    print(f"  已关闭 CH{ch} 输出")
            dev.close()
            print("  连接已关闭")
        except Exception as exc:
            print(f"  ⚠ 收尾出错: {type(exc).__name__}: {exc}")

    return 0 if res.summary() else 1


if __name__ == "__main__":
    sys.exit(main())
